
// let $box1 = document.getElementById("box1");
// console.log($box1);

// setInterval(function () {$box1.classList.add('box1')}, 2000);
// setInterval(function () {$box1.classList.remove('box1')}, 4000);